import random
import bot

class Arena:
    @staticmethod
    def battle(bot1: bot, bot2: bot):
        print("Starting battle between {} and {}".format(bot1, bot2))
        
        while bot1.hp > 0 and bot2.hp > 0:
            if random.choice([True, False]):
                # bot 1 attacks bot 2
                damage = bot1.attack()
                bot2 - damage
                print("{} attacks {} for {} damage".format(bot1, bot2, damage))
            else:
                # bot 2 attacks bot 1
                damage = bot2.attack()
                bot1 - damage
                print("{} attacks {} for {} damage".format(bot2, bot1, damage))

        if bot1.hp <= 0:
            winner = bot2
        elif bot2.hp <= 0:
            winner = bot1
        else:
            winner = None
        
        if winner:
            print("Winner: {}".format(winner))
        else:
            print("Draw!")

        return winner

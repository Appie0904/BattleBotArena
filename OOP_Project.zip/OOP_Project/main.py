from player import Player
from tankbot import TankBot
from speedbot import SpeedBot
from weapon import Weapon
from arena import Arena

def main():

    # Players
    player1 = Player("Lorenzo")
    player2 = Player("Jasper")

    # Bots
    tank_bot = TankBot("Steve")
    speed_bot = SpeedBot("Alex")
    laser = Weapon.create_basic_weapon()

    speed_bot += laser # using operator overloading
    player1 += tank_bot
    player2 += speed_bot

    # Fight
    winner = Arena.battle(tank_bot, speed_bot)

    if winner == tank_bot:
        player1.score += 1
    elif winner == speed_bot:
        player2.score += 1
    else:
        player1.score += 0.5
        player2.score += 0.5

    print(player1)
    print(player2)

if __name__ == "__main__":
    main()



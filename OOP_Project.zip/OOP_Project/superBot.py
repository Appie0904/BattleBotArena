from bot import BotMaker

class TankBot(BotMaker):
    def __init__(self, name):
        super().__init__(name, power=50, armor=100, speed=1)

    def attack(self):
        return super().attack() + 10  # Extra damage

    def special_move(self):
        self._power += 30
        print(f"{self.__class__.__name__} power upgraded!")

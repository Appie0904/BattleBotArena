class Player:
    def __init__(self, name: str):
        self.__name = name
        self._bots = []
        self.score = 0

    
    def add_bot(self, bot):
        self._bots.append(bot)
    
    @property
    def bots(self):
        return self._bots

    @classmethod
    def from_string(cls, string: str):
        name = string.strip()
        return cls(name)

    def __str__(self):
        return f"Player: {self.__name}, Bots: {len(self._bots)}, Score: {self.score}"
    
    def __gt__(self, other):
        return self.score > other.score
    
    def __ne__(self, other):
        return self._bots != other.bots
    
    def __iadd__(self, bot):
        self.add_bot(bot)
        return self
